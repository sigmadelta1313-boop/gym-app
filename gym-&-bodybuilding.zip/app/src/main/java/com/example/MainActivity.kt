package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.theme.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// Sealed-class for robust Navigation Tab State
sealed class GymScreen(val route: String, val titleFa: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
    object Home : GymScreen("home", "خانه", Icons.Default.Home)
    object Workouts : GymScreen("workouts", "تمرینات", Icons.Default.PlayArrow)
    object Exercises : GymScreen("exercises", "حرکات", Icons.Default.List)
    object AiCoach : GymScreen("ai_coach", "مربی هوش مصنوعی", Icons.Default.Star)
    object History : GymScreen("history", "سابقه", Icons.Default.Menu)
}

// Set state representations
data class LoggedSetState(
    val setIndex: Int,
    val weight: String,
    val reps: String,
    val isCompleted: Boolean = false
)

data class ActiveWorkoutState(
    val routine: WorkoutRoutine,
    val exercises: List<RoutineExercise>,
    val loggedSets: Map<Int, List<LoggedSetState>> = emptyMap(), // exerciseIndex -> list of sets
    val activeExerciseIndex: Int = 0,
    val durationSeconds: Int = 0,
    val activeRestTimer: Int = 0, // in seconds
    val isRestTimerRunning: Boolean = false
)

// Main ViewModel holding the business layer
class GymViewModel(private val repository: GymRepository) : ViewModel() {
    
    val routines: StateFlow<List<WorkoutRoutine>> = repository.allRoutines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val workoutLogs: StateFlow<List<WorkoutLog>> = repository.allWorkoutLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active screen route
    private val _currentScreen = MutableStateFlow<GymScreen>(GymScreen.Home)
    val currentScreen: StateFlow<GymScreen> = _currentScreen.asStateFlow()

    // Active Workout Logger State
    private val _activeWorkout = MutableStateFlow<ActiveWorkoutState?>(null)
    val activeWorkout: StateFlow<ActiveWorkoutState?> = _activeWorkout.asStateFlow()

    // AI Coach Chat State
    private val _chatHistory = MutableStateFlow<List<Pair<String, Boolean>>>(
        listOf(
            Pair("سلام قهرمان! به باشگاه مجازی خودت خوش اومدی. من مربی تمرین و تغذیه اختصاصیِ تو هستم. چطور می‌تونم امروز در ساختن فرم بدنی ایده‌آلت کمکت کنم؟", false)
        )
    )
    val chatHistory: StateFlow<List<Pair<String, Boolean>>> = _chatHistory.asStateFlow()

    private val _isChatLoading = MutableStateFlow(false)
    val isChatLoading: StateFlow<Boolean> = _isChatLoading.asStateFlow()

    private var timerJob: Job? = null

    init {
        // Pre-populate demo routines for an exceptional first launch UX!
        viewModelScope.launch {
            val routinesList = repository.allRoutines.first()
            if (routinesList.isEmpty()) {
                // 1. Push Day (سینه و سرشانه)
                val pushId = repository.insertRoutine(
                    WorkoutRoutine(
                        name = "برنامه فشاری (سینه، سرشانه و پشت‌بازو)",
                        notes = "تمرین تمرکزی برای عضله‌سازی بالاتنه و افزایش قدرت پرس"
                    )
                )
                repository.insertRoutineExercise(RoutineExercise(routineId = pushId.toInt(), exerciseName = "Barbell Bench Press", targetSets = 4, targetReps = "10", targetWeight = 60.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pushId.toInt(), exerciseName = "Incline Dumbbell Press", targetSets = 3, targetReps = "12", targetWeight = 24.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pushId.toInt(), exerciseName = "Barbell Overhead Press", targetSets = 3, targetReps = "10", targetWeight = 35.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pushId.toInt(), exerciseName = "Dumbbell Lateral Raise", targetSets = 4, targetReps = "15", targetWeight = 10.0))

                // 2. Pull Day (پشت و بازو)
                val pullId = repository.insertRoutine(
                    WorkoutRoutine(
                        name = "برنامه کششی (پشت، زیربغل و جلوبازو)",
                        notes = "ساخت عضلات عریض پشتی (هفتی شکل) و پمپ عضلات جلوبازو"
                    )
                )
                repository.insertRoutineExercise(RoutineExercise(routineId = pullId.toInt(), exerciseName = "Pull-up", targetSets = 3, targetReps = "10", targetWeight = 0.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pullId.toInt(), exerciseName = "Lat Pulldown", targetSets = 4, targetReps = "12", targetWeight = 50.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pullId.toInt(), exerciseName = "Bent Over Barbell Row", targetSets = 3, targetReps = "10", targetWeight = 50.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = pullId.toInt(), exerciseName = "Barbell Bicep Curl", targetSets = 4, targetReps = "12", targetWeight = 25.0))

                // 3. Leg Day (پا و شکم)
                val legId = repository.insertRoutine(
                    WorkoutRoutine(
                        name = "برنامه پا و عضلات شکم",
                        notes = "تقویت عضلات پا، همسترینگ و ثبات مرکز بدن"
                    )
                )
                repository.insertRoutineExercise(RoutineExercise(routineId = legId.toInt(), exerciseName = "Barbell Back Squat", targetSets = 4, targetReps = "8", targetWeight = 80.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = legId.toInt(), exerciseName = "Romanian Deadlift", targetSets = 4, targetReps = "10", targetWeight = 70.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = legId.toInt(), exerciseName = "Abdominal Crunch", targetSets = 3, targetReps = "15", targetWeight = 0.0))
                repository.insertRoutineExercise(RoutineExercise(routineId = legId.toInt(), exerciseName = "Isometric Plank", targetSets = 3, targetReps = "60 ثانیه", targetWeight = 0.0))
            }
        }
    }

    fun navigateTo(screen: GymScreen) {
        _currentScreen.value = screen
    }

    // Start active workout tracking
    fun startWorkout(routine: WorkoutRoutine) {
        viewModelScope.launch {
            repository.getExercisesForRoutine(routine.id).first().let { exercises ->
                val setsMap = mutableMapOf<Int, List<LoggedSetState>>()
                exercises.forEachIndexed { index, exe ->
                    val setsList = List(exe.targetSets) { idx ->
                        LoggedSetState(
                            setIndex = idx + 1,
                            weight = exe.targetWeight.toInt().toString(),
                            reps = exe.targetReps,
                            isCompleted = false
                        )
                    }
                    setsMap[index] = setsList
                }

                _activeWorkout.value = ActiveWorkoutState(
                    routine = routine,
                    exercises = exercises,
                    loggedSets = setsMap,
                    activeExerciseIndex = 0,
                    durationSeconds = 0,
                    activeRestTimer = 0,
                    isRestTimerRunning = false
                )
                startWorkoutTimer()
            }
        }
    }

    private fun startWorkoutTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _activeWorkout.update { state ->
                    state?.let {
                        val nextRest = if (it.isRestTimerRunning && it.activeRestTimer > 0) {
                            it.activeRestTimer - 1
                        } else {
                            0
                        }
                        val isRestRunning = if (nextRest == 0) false else it.isRestTimerRunning
                        it.copy(
                            durationSeconds = it.durationSeconds + 1,
                            activeRestTimer = nextRest,
                            isRestTimerRunning = isRestRunning
                        )
                    }
                }
            }
        }
    }

    fun updateSetLog(exerciseIndex: Int, setIndex: Int, weight: String, reps: String, isCompleted: Boolean) {
        _activeWorkout.update { state ->
            state?.let { s ->
                val currentSets = s.loggedSets[exerciseIndex]?.toMutableList() ?: mutableListOf()
                val targetIdx = currentSets.indexOfFirst { it.setIndex == setIndex }
                if (targetIdx != -1) {
                    currentSets[targetIdx] = currentSets[targetIdx].copy(
                        weight = weight,
                        reps = reps,
                        isCompleted = isCompleted
                    )
                }
                val newLoggedSets = s.loggedSets.toMutableMap()
                newLoggedSets[exerciseIndex] = currentSets
                
                // If a set is newly marked completed, trigger a nice 60s Rest Timer to keep workout paced!
                val newlyCompleted = isCompleted && !(s.loggedSets[exerciseIndex]?.find { it.setIndex == setIndex }?.isCompleted ?: false)
                val restTime = if (newlyCompleted) 60 else s.activeRestTimer
                val restRunning = newlyCompleted || s.isRestTimerRunning

                s.copy(
                    loggedSets = newLoggedSets,
                    activeRestTimer = restTime,
                    isRestTimerRunning = restRunning
                )
            }
        }
    }

    fun addSetToActiveExercise(exerciseIndex: Int) {
        _activeWorkout.update { state ->
            state?.let { s ->
                val currentSets = s.loggedSets[exerciseIndex]?.toMutableList() ?: mutableListOf()
                val nextIndex = (currentSets.maxOfOrNull { it.setIndex } ?: 0) + 1
                val lastSet = currentSets.lastOrNull()
                currentSets.add(
                    LoggedSetState(
                        setIndex = nextIndex,
                        weight = lastSet?.weight ?: "20",
                        reps = lastSet?.reps ?: "10",
                        isCompleted = false
                    )
                )
                val newLoggedSets = s.loggedSets.toMutableMap()
                newLoggedSets[exerciseIndex] = currentSets
                s.copy(loggedSets = newLoggedSets)
            }
        }
    }

    fun removeSetFromActiveExercise(exerciseIndex: Int, setIndex: Int) {
        _activeWorkout.update { state ->
            state?.let { s ->
                val currentSets = s.loggedSets[exerciseIndex]?.toMutableList() ?: mutableListOf()
                currentSets.removeAll { it.setIndex == setIndex }
                val newLoggedSets = s.loggedSets.toMutableMap()
                newLoggedSets[exerciseIndex] = currentSets
                s.copy(loggedSets = newLoggedSets)
            }
        }
    }

    fun changeActiveExercise(index: Int) {
        _activeWorkout.update { state ->
            state?.copy(activeExerciseIndex = index)
        }
    }

    fun startRestTimerManually(seconds: Int) {
        _activeWorkout.update { state ->
            state?.copy(
                activeRestTimer = seconds,
                isRestTimerRunning = true
            )
        }
    }

    fun discardWorkout() {
        timerJob?.cancel()
        _activeWorkout.value = null
    }

    fun finishWorkoutAndSave() {
        val state = _activeWorkout.value ?: return
        timerJob?.cancel()
        viewModelScope.launch {
            val durationMin = state.durationSeconds / 60
            val exerciseLogs = mutableListOf<ExerciseSetLog>()
            
            state.loggedSets.forEach { (exeIdx, sets) ->
                val exerciseName = state.exercises[exeIdx].exerciseName
                sets.forEach { set ->
                    if (set.isCompleted) {
                        exerciseLogs.add(
                            ExerciseSetLog(
                                workoutLogId = 0, // Assigned by repository
                                exerciseName = exerciseName,
                                setIndex = set.setIndex,
                                weight = set.weight.toDoubleOrNull() ?: 0.0,
                                reps = set.reps.toIntOrNull() ?: 0
                            )
                        )
                    }
                }
            }

            if (exerciseLogs.isEmpty()) {
                // If no set was checked, at least log standard sets as reference
                state.loggedSets.forEach { (exeIdx, sets) ->
                    val exerciseName = state.exercises[exeIdx].exerciseName
                    sets.take(1).forEach { set ->
                        exerciseLogs.add(
                            ExerciseSetLog(
                                workoutLogId = 0,
                                exerciseName = exerciseName,
                                setIndex = set.setIndex,
                                weight = set.weight.toDoubleOrNull() ?: 20.0,
                                reps = set.reps.toIntOrNull() ?: 10
                            )
                        )
                    }
                }
            }

            repository.addWorkoutSession(
                routineName = state.routine.name,
                durationMin = if (durationMin == 0) 1 else durationMin,
                sets = exerciseLogs
            )
            
            _activeWorkout.value = null
            navigateTo(GymScreen.History)
        }
    }

    // Add normal Routine
    fun createCustomRoutine(name: String, notes: String, selectedExercises: List<GymExercise>) {
        viewModelScope.launch {
            val routineId = repository.insertRoutine(WorkoutRoutine(name = name, notes = notes))
            selectedExercises.forEach { exe ->
                repository.insertRoutineExercise(
                    RoutineExercise(
                        routineId = routineId.toInt(),
                        exerciseName = exe.nameEn,
                        targetSets = 3,
                        targetReps = "10",
                        targetWeight = 20.0
                    )
                )
            }
        }
    }

    fun deleteRoutine(routineId: Int) {
        viewModelScope.launch {
            repository.deleteRoutine(routineId)
        }
    }

    fun deleteWorkoutLog(logId: Int) {
        viewModelScope.launch {
            repository.deleteWorkoutLog(logId)
        }
    }

    // Log detail accessor
    fun getSetLogsForWorkout(workoutLogId: Int): Flow<List<ExerciseSetLog>> {
        return repository.getSetLogsForWorkout(workoutLogId)
    }

    // AI Coach Interaction with System Instructions
    fun askAiCoach(userMsg: String) {
        if (userMsg.isBlank()) return

        // Append user prompt instantly
        _chatHistory.value = _chatHistory.value + Pair(userMsg, true)
        _isChatLoading.value = true

        viewModelScope.launch {
            val systemInstruction = """
                You are a very encouraging, professional gym coach and sports nutritionist for bodybuilders (called "مربی رستم"). 
                You respond only in Persian. You focus on bodybuilding, muscle gain, protein intake, cutting, bulking, correct forms, and gym safety.
                Structure your answers with paragraphs, bullet points, and sport terminology (like چربی‌سوزی, سنتز پروتئین, ست‌های تمرینی, اورلود تدریجی).
                Keep the tone extremely motivating, polite, athletic, and friendly! Use terms like "قهرمان" or "ورزشکار" to refer to the user.
            """.trimIndent()

            val aiResponse = GeminiService.generateContent(userMsg, systemInstruction)
            _chatHistory.value = _chatHistory.value + Pair(aiResponse, false)
            _isChatLoading.value = false
        }
    }

    fun clearChat() {
        _chatHistory.value = listOf(
            Pair("سلام قهرمان! جلسه‌ی جدید مشاوره رو شروع کنیم. در مورد برنامه تمرینی، تغذیه یا مکمل‌ها چه سوالی داری؟", false)
        )
    }
}

// Custom ViewModel Factory
class GymViewModelFactory(private val repository: GymRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GymViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GymViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// Activity Base
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Init Room DB and repository
        val database = GymDatabase.getDatabase(applicationContext)
        val repository = GymRepository(database.workoutDao())
        
        setContent {
            MyApplicationTheme {
                GymAppSurface(repository)
            }
        }
    }
}

// Central Composable coordinating Active Workouts, Navigation Bar, Screens
@OptIn(ExperimentalAnimationApi::class)
@Composable
fun GymAppSurface(repository: GymRepository) {
    val viewModel: GymViewModel = viewModel(factory = GymViewModelFactory(repository))
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val activeWorkout by viewModel.activeWorkout.collectAsStateWithLifecycle()

    Scaffold(
        bottomBar = {
            if (activeWorkout == null) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    windowInsets = WindowInsets.navigationBars
                ) {
                    val tabs = listOf(
                        GymScreen.Home,
                        GymScreen.Workouts,
                        GymScreen.Exercises,
                        GymScreen.AiCoach,
                        GymScreen.History
                    )
                    tabs.forEach { tab ->
                        val isSelected = currentScreen.route == tab.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(tab) },
                            icon = {
                                Icon(
                                    imageVector = tab.icon,
                                    contentDescription = tab.titleFa,
                                    tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            },
                            label = {
                                Text(
                                    text = tab.titleFa,
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Screen switching with a gorgeous horizontal/vertical fade-in animation
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    GymScreen.Home -> HomeScreen(viewModel)
                    GymScreen.Workouts -> WorkoutsScreen(viewModel)
                    GymScreen.Exercises -> ExercisesCatalogScreen()
                    GymScreen.AiCoach -> AiCoachScreen(viewModel)
                    GymScreen.History -> HistoryLogsScreen(viewModel)
                }
            }

            // Gorgeous Sliding Overlay for Active Workouts (like standard premium workout apps)
            AnimatedVisibility(
                visible = activeWorkout != null,
                enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                activeWorkout?.let { state ->
                    ActiveWorkoutLoggerUI(state = state, viewModel = viewModel)
                }
            }
        }
    }
}

// ---------------- HOME SCREEN ----------------

@Composable
fun HomeScreen(viewModel: GymViewModel) {
    val routines by viewModel.routines.collectAsStateWithLifecycle()
    val logs by viewModel.workoutLogs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        // Hero Photo Card with bold motivational typography overlay
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(210.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .shadow(4.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.img_bodybuilding_hero),
                    contentDescription = "بدنسازی و تناسب اندام",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                // Dark dynamic gold gradient mask
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)),
                                startY = 100f
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.Bottom,
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "باشگاه حرفه‌ایِ آهن و اراده",
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.End
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "با مربی هوش مصنوعی، تمریناتت رو ثبت و با برنامه علمی پیش برو",
                        color = Color.White.copy(alpha = 0.9f),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.End,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Streak & Quick Stats
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Total workouts logged Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = "تمرینات ثبت شده",
                            tint = GymGreen,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${logs.size} جلسه",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "تمرین ثبت شده",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )
                    }
                }

                // AI Coaching Streak Advice Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = "مربی آنلاین",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "مربی رستم",
                            color = MaterialTheme.colorScheme.onSurface,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "آماده پاسخ به تو",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Quick Workouts Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "برنامه‌های آماده تمرین",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "مشاهده همه",
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 12.sp,
                    modifier = Modifier.clickable { viewModel.navigateTo(GymScreen.Workouts) }
                )
            }
        }

        // Show pre-populated premium routines to trigger instant gym starting
        if (routines.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "در حال بارگذاری روال‌های تمرینی...",
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        } else {
            items(routines.take(2)) { routine ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.startWorkout(routine) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Start workout quick button
                        Button(
                            onClick = { viewModel.startWorkout(routine) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text(
                                text = "شروع تمرین",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimary,
                                fontSize = 12.sp
                            )
                        }

                        // Workout Information
                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.weight(1f).padding(end = 12.dp)
                        ) {
                            Text(
                                text = routine.name,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                textAlign = TextAlign.End
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = routine.notes,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontSize = 11.sp,
                                textAlign = TextAlign.End,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }

        // Pro Gym Tip Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "نکته مربی",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "نکته‌ی طلایی رشد عضله",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "اورلود تدریجی (افزایش تدریجی وزنه یا تکرارها در هفته جدید) تضمین‌کننده‌ی افزایش حجم بافت عضلانی است. تمام ست‌هایت را ثبت کن تا بر آن نظارت داشته باشی.",
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            fontSize = 11.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

// ---------------- WORKOUTS ROUTINES SCREEN ----------------

@Composable
fun WorkoutsScreen(viewModel: GymViewModel) {
    val routines by viewModel.routines.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var routineName by remember { mutableStateOf("") }
    var routineNotes by remember { mutableStateOf("") }

    // Preselected catalog for routine creation
    val presetExercises = ExerciseData.exercises

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp))
                            .size(40.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "روال جدید",
                            tint = MaterialTheme.colorScheme.onPrimary
                        )
                    }
                    Text(
                        text = "روال‌های بدنسازی من",
                        color = MaterialTheme.colorScheme.onBackground,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                }
            }

            if (routines.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "هنوز برنامه‌ای نساخته‌ای. دکمه + در بالا را بزن!",
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                items(routines) { routine ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                // Delete icon
                                IconButton(onClick = { viewModel.deleteRoutine(routine.id) }) {
                                    Icon(
                                        imageVector = Icons.Default.Delete,
                                        contentDescription = "حذف روال",
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                    )
                                }

                                // Routine Title
                                Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = routine.name,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.End
                                    )
                                    if (routine.notes.isNotEmpty()) {
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = routine.notes,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                            fontSize = 12.sp,
                                            textAlign = TextAlign.End
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Action: Start Active Tracker
                            Button(
                                onClick = { viewModel.startWorkout(routine) },
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("شروع تمرین و ثبت آمار", fontWeight = FontWeight.Bold)
                                    Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "شروع")
                                }
                            }
                        }
                    }
                }
            }
        }

        // Custom Add Routine Dialog
        if (showAddDialog) {
            var selectedIndexes = remember { mutableStateListOf<Int>() }

            AlertDialog(
                onDismissRequest = { showAddDialog = false },
                confirmButton = {
                    Button(
                        onClick = {
                            if (routineName.isNotBlank()) {
                                val workoutsToAdd = selectedIndexes.map { presetExercises[it] }
                                viewModel.createCustomRoutine(routineName, routineNotes, workoutsToAdd)
                                routineName = ""
                                routineNotes = ""
                                showAddDialog = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("ایجاد")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showAddDialog = false }) {
                        Text("انصراف")
                    }
                },
                title = {
                    Text(
                        text = "ایجاد برنامه بدنسازی جدید",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        // Title input
                        OutlinedTextField(
                            value = routineName,
                            onValueChange = { routineName = it },
                            label = { Text("نام برنامه (مثال: بالاتنه حجمی)") },
                            modifier = Modifier.fillMaxWidth(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
                        )

                        // Notes input
                        OutlinedTextField(
                            value = routineNotes,
                            onValueChange = { routineNotes = it },
                            label = { Text("توضیحات (اختیاری)") },
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "انتخاب حرکات تمرینی:",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Listed preselected exercises
                        presetExercises.forEachIndexed { idx, exe ->
                            val isSelected = selectedIndexes.contains(idx)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (isSelected) {
                                            selectedIndexes.remove(idx)
                                        } else {
                                            selectedIndexes.add(idx)
                                        }
                                    }
                                    .background(
                                        if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                        else Color.Transparent,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (isSelected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "انتخاب شده",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                } else {
                                    Spacer(modifier = Modifier.width(24.dp))
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(text = exe.nameFa, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(text = exe.primaryMuscleFa, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                                }
                            }
                        }
                    }
                }
            )
        }
    }
}

// ---------------- EXERCISES CATALOG SCREEN ----------------

@Composable
fun ExercisesCatalogScreen() {
    var selectedCategory by remember { mutableStateOf("All") }
    val categories = listOf(Pair("All", "همه")) + ExerciseData.categories
    val exercises = ExerciseData.exercises

    var searchPhrase by remember { mutableStateOf("") }
    var activeDetailExercise by remember { mutableStateOf<GymExercise?>(null) }

    val filteredExercises = exercises.filter { exe ->
        val catMatch = selectedCategory == "All" || exe.categoryEn == selectedCategory
        val searchMatch = searchPhrase.isEmpty() ||
                exe.nameFa.contains(searchPhrase, ignoreCase = true) ||
                exe.nameEn.contains(searchPhrase, ignoreCase = true) ||
                exe.primaryMuscleFa.contains(searchPhrase, ignoreCase = true)
        catMatch && searchMatch
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Headers and search
        item {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "دانشنامه تخصصی حرکات بدنسازی",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )

                // Search Bar
                OutlinedTextField(
                    value = searchPhrase,
                    onValueChange = { searchPhrase = it },
                    placeholder = { Text("جستجوی حرکت یا عضله هدف...") },
                    modifier = Modifier.fillMaxWidth(),
                    leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "جستجو") },
                    singleLine = true
                )
            }
        }

        // Horizontal Category Filter Pills
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                categories.forEach { (en, fa) ->
                    val isSelected = selectedCategory == en
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedCategory = en },
                        label = { Text(text = fa, fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )
                }
            }
        }

        // Exercise List Cards
        if (filteredExercises.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "حرکت تمرینی یافت نشد.",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        } else {
            items(filteredExercises) { exe ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeDetailExercise = exe },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "جزئیات حرکت",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )

                        // Body/Headers
                        Column(
                            horizontalAlignment = Alignment.End,
                            modifier = Modifier.weight(1f).padding(end = 12.dp)
                        ) {
                            Text(
                                text = exe.nameFa,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "عضله اصلی: ${exe.primaryMuscleFa}",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f),
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Interactive Instruction Detail Dialog
    activeDetailExercise?.let { exe ->
        AlertDialog(
            onDismissRequest = { activeDetailExercise = null },
            confirmButton = {
                Button(
                    onClick = { activeDetailExercise = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text("فهمیدم قهرمان!")
                }
            },
            title = {
                Text(
                    text = exe.nameFa,
                    fontWeight = FontWeight.Black,
                    color = MaterialTheme.colorScheme.primary,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    // Muscle Target badge
                    Row(
                        modifier = Modifier
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.12f), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "عضله درگیر: ${exe.primaryMuscleFa} (${exe.primaryMuscleEn})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Description fa
                    Text(
                        text = exe.descriptionFa,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "آموزش گام به گام اجرا:",
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Staggered layout list steps
                    exe.instructions.forEachIndexed { i, step ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = step,
                                modifier = Modifier.weight(1f).padding(end = 8.dp),
                                fontSize = 12.sp,
                                textAlign = TextAlign.Right,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                            )
                            Box(
                                modifier = Modifier
                                    .size(20.dp)
                                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${i + 1}",
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        )
    }
}

// ---------------- AI COACH SCREEN (GEMINI POWERED) ----------------

@Composable
fun AiCoachScreen(viewModel: GymViewModel) {
    val chatHistory by viewModel.chatHistory.collectAsStateWithLifecycle()
    val isLoading by viewModel.isChatLoading.collectAsStateWithLifecycle()
    var userTextPrompt by remember { mutableStateOf("") }

    val suggestedQuestions = listOf(
        "برنامه تغذیه برای حجم عضلانی چیست؟",
        "حرکت اسکات چظور درست اجرا میشه؟",
        "برای چربی‌سوزی چقدر پروتئین لازمه؟",
        "یک برنامه تمرینی ۴ روزه برام بنویس"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Headers with a Clear Chat option
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.clearChat() },
                modifier = Modifier.background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "پاک کردن چت",
                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "مشاوره با مربی رستم (هوش مصنوعی)",
                    color = MaterialTheme.colorScheme.onBackground,
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp
                )
                Text(
                    text = "پاسخ رژیم مکمل و تمرین با Gemini-3.5",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }
        }

        // Chat Bubble Flow
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(chatHistory) { (msg, isUser) ->
                    Box(
                        modifier = Modifier.fillMaxWidth(),
                        contentAlignment = if (isUser) Alignment.CenterEnd else Alignment.CenterStart
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) MaterialTheme.colorScheme.primary
                                else MaterialTheme.colorScheme.surfaceVariant
                            ),
                            shape = RoundedCornerShape(
                                topStart = 12.dp,
                                topEnd = 12.dp,
                                bottomStart = if (isUser) 12.dp else 2.dp,
                                bottomEnd = if (isUser) 2.dp else 12.dp
                            ),
                            modifier = Modifier.widthIn(max = 280.dp)
                        ) {
                            Text(
                                text = msg,
                                modifier = Modifier.padding(12.dp),
                                color = if (isUser) MaterialTheme.colorScheme.onPrimary
                                else MaterialTheme.colorScheme.onSurface,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Right
                            )
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Box(
                            modifier = Modifier.fillMaxWidth(),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.padding(8.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                                    Text("مربی در حال نوشتن پاسخ علمی...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Horizontal Suggested workout chips
        if (chatHistory.size == 1) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                suggestedQuestions.forEach { prompt ->
                    SuggestionChip(
                        onClick = { viewModel.askAiCoach(prompt) },
                        label = { Text(text = prompt, fontSize = 10.sp, fontWeight = FontWeight.Bold) }
                    )
                }
            }
        }

        // Input bottom tray
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    if (userTextPrompt.isNotBlank()) {
                        viewModel.askAiCoach(userTextPrompt)
                        userTextPrompt = ""
                    }
                },
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(12.dp))
                    .size(48.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Send,
                    contentDescription = "ارسال به مربی",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
            }

            OutlinedTextField(
                value = userTextPrompt,
                onValueChange = { userTextPrompt = it },
                placeholder = { Text("سوالت رو از مربی رستم بپرس...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
        }
    }
}

// ---------------- HISTORY LOGS SCREEN ----------------

@Composable
fun HistoryLogsScreen(viewModel: GymViewModel) {
    val logs by viewModel.workoutLogs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "تاریخچه جلسات ثبت شده",
                color = MaterialTheme.colorScheme.onBackground,
                fontWeight = FontWeight.Black,
                fontSize = 18.sp,
                modifier = Modifier.fillMaxWidth(),
                textAlign = TextAlign.Right
            )
        }

        if (logs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "هنوز جلسه تمرینی ثبت نکرده‌اید قهرمان. تمرین کن و نام خود را جاودانه کن!",
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.61f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            items(logs) { log ->
                val formatter = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US) }
                val dateStr = remember(log.timestamp) { formatter.format(Date(log.timestamp)) }
                val setsListState = viewModel.getSetLogsForWorkout(log.id).collectAsStateWithLifecycle(emptyList())

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.deleteWorkoutLog(log.id) }) {
                                Icon(
                                    imageVector = Icons.Default.Delete,
                                    contentDescription = "حذف رکورد",
                                    tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = log.routineName,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary,
                                    textAlign = TextAlign.End
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "مدت زمان: ${log.durationMinutes} دقیقه",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                    Text(
                                        text = "•",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                    )
                                    Text(
                                        text = dateStr,
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        }

                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                        // Complete list of logged exercises under this session
                        if (setsListState.value.isEmpty()) {
                            Text(
                                text = "در حال خواندن جزئیات تمرین...",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.Right
                            )
                        } else {
                            // Group sets by exercise name and show
                            val groupedSets = setsListState.value.groupBy { it.exerciseName }
                            groupedSets.forEach { (exeName, sets) ->
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.End
                                ) {
                                    Text(
                                        text = exeName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    // Row showing logged weights + reps
                                    val logDetails = sets.joinToString("، ") { "ست ${it.setIndex}: ${it.weight} ک.گ × ${it.reps} تکرار" }
                                    Text(
                                        text = logDetails,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- ACTIVE WORKOUT TRACKER SHEET UI ----------------

@Composable
fun ActiveWorkoutLoggerUI(state: ActiveWorkoutState, viewModel: GymViewModel) {
    val formatter = remember { SimpleDateFormat("mm:ss", Locale.US) }
    val formattedDuration = remember(state.durationSeconds) {
        val min = state.durationSeconds / 60
        val sec = state.durationSeconds % 60
        String.format(Locale.US, "%02d:%02d", min, sec)
    }

    Scaffold(
        topBar = {
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Header title & Timer
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Timer row
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "زمان تمرین",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = formattedDuration,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        // Close Workout logger prompt
                        TextButton(onClick = { viewModel.discardWorkout() }) {
                            Text("لغو تمرین", color = MaterialTheme.colorScheme.error)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Finish Button
                        Button(
                            onClick = { viewModel.finishWorkoutAndSave() },
                            colors = ButtonDefaults.buttonColors(containerColor = GymGreen)
                        ) {
                            Text("ثبت و اتمام تمرین", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        // Active routine title
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "جلسه حین تمرین",
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                                fontSize = 11.sp
                            )
                            Text(
                                text = state.routine.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface,
                                textAlign = TextAlign.End
                            )
                        }
                    }

                    // Rest Timer indicator bar
                    if (state.activeRestTimer > 0 && state.isRestTimerRunning) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f))
                                .padding(vertical = 6.dp, horizontal = 12.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "استراحت: ${state.activeRestTimer} ثانیه",
                                    color = MaterialTheme.colorScheme.primary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "به عضله اجازه ریکاوری بدهید",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.8f)
                                )
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            // Horizontal scrolling exercises selector tabs
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    state.exercises.forEachIndexed { i, exe ->
                        val isActive = state.activeExerciseIndex == i
                        FilterChip(
                            selected = isActive,
                            onClick = { viewModel.changeActiveExercise(i) },
                            label = { Text(text = exe.exerciseName, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }
            }

            // Target Active Exercise details
            if (state.exercises.isNotEmpty() && state.activeExerciseIndex < state.exercises.size) {
                val currentExe = state.exercises[state.activeExerciseIndex]
                val setLogs = state.loggedSets[state.activeExerciseIndex] ?: emptyList()

                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            // Exercise name & target goal hints
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { viewModel.addSetToActiveExercise(state.activeExerciseIndex) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                                    contentPadding = PaddingValues(horizontal = 8.dp)
                                ) {
                                    Text("+ افزودن ست", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = currentExe.exerciseName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "هدف: ${currentExe.targetSets} ست × ${currentExe.targetReps} تکرار",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.61f)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Table Headers
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "رابطه / حذف", modifier = Modifier.width(60.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(text = "تکرار", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(text = "وزنه (کیلو)", modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                                Text(text = "ست", modifier = Modifier.width(36.dp), textAlign = TextAlign.Center, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f))
                            }

                            Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

                            // Listed clickable dynamic sets logger
                            setLogs.forEach { set ->
                                var weightVal by remember(set.weight) { mutableStateOf(set.weight) }
                                var repsVal by remember(set.reps) { mutableStateOf(set.reps) }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                        .background(
                                            if (set.isCompleted) MaterialTheme.colorScheme.primary.copy(alpha = 0.07f)
                                            else Color.Transparent,
                                            RoundedCornerShape(8.dp)
                                        ),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    // Complete checkbox & delete trigger
                                    Row(
                                        modifier = Modifier.width(60.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        IconButton(
                                            onClick = { viewModel.removeSetFromActiveExercise(state.activeExerciseIndex, set.setIndex) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Delete,
                                                contentDescription = "حذف ست",
                                                tint = MaterialTheme.colorScheme.error.copy(alpha = 0.8f),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        Checkbox(
                                            checked = set.isCompleted,
                                            onCheckedChange = { isChecked ->
                                                viewModel.updateSetLog(
                                                    exerciseIndex = state.activeExerciseIndex,
                                                    setIndex = set.setIndex,
                                                    weight = weightVal,
                                                    reps = repsVal,
                                                    isCompleted = isChecked
                                                )
                                            },
                                            modifier = Modifier.size(24.dp),
                                            colors = CheckboxDefaults.colors(
                                                checkedColor = GymGreen,
                                                uncheckedColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                            )
                                        )
                                    }

                                    // Reps Input
                                    OutlinedTextField(
                                        value = repsVal,
                                        onValueChange = {
                                            repsVal = it
                                            viewModel.updateSetLog(
                                                exerciseIndex = state.activeExerciseIndex,
                                                setIndex = set.setIndex,
                                                weight = weightVal,
                                                reps = it,
                                                isCompleted = set.isCompleted
                                            )
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 4.dp)
                                            .height(48.dp),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center, fontSize = 12.sp)
                                    )

                                    // Weight Input
                                    OutlinedTextField(
                                        value = weightVal,
                                        onValueChange = {
                                            weightVal = it
                                            viewModel.updateSetLog(
                                                exerciseIndex = state.activeExerciseIndex,
                                                setIndex = set.setIndex,
                                                weight = it,
                                                reps = repsVal,
                                                isCompleted = set.isCompleted
                                            )
                                        },
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 4.dp)
                                            .height(48.dp),
                                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                        singleLine = true,
                                        textStyle = LocalTextStyle.current.copy(textAlign = TextAlign.Center, fontSize = 12.sp)
                                    )

                                    // Index tag
                                    Box(
                                        modifier = Modifier
                                            .width(36.dp)
                                            .height(36.dp)
                                            .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(18.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${set.setIndex}",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick rest buttons
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.startRestTimerManually(90) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("۹۰ ثانیه استراحت", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { viewModel.startRestTimerManually(60) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("۶۰ ثانیه استراحت", color = MaterialTheme.colorScheme.primary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
