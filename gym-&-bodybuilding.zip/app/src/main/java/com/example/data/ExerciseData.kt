package com.example.data

data class GymExercise(
    val id: String,
    val nameEn: String,
    val nameFa: String,
    val categoryEn: String,
    val categoryFa: String,
    val descriptionEn: String,
    val descriptionFa: String,
    val primaryMuscleEn: String,
    val primaryMuscleFa: String,
    val instructions: List<String>
)

object ExerciseData {
    val categories = listOf(
        Pair("Chest", "سینه"),
        Pair("Back", "پشت و زیربغل"),
        Pair("Shoulders", "سرشانه"),
        Pair("Legs", "پا"),
        Pair("Arms", "بازو"),
        Pair("Core", "شکم و فیله")
    )

    val exercises = listOf(
        // Chest
        GymExercise(
            id = "bench_press",
            nameEn = "Barbell Bench Press",
            nameFa = "پرس سینه هالتر",
            categoryEn = "Chest",
            categoryFa = "سینه",
            descriptionEn = "A classic compound movement that is the gold standard for build chest size and strength.",
            descriptionFa = "حرکت ترکیبی کلاسیک که استاندارد طلایی برای ساخت حجم و قدرت عضلات سینه است.",
            primaryMuscleEn = "Pectorals (Chest)",
            primaryMuscleFa = "عضلات سینه",
            instructions = listOf(
                "روی نیمکت صاف دراز بکشید و هالتر را با دست‌هایی کمی بازتر از عرض شانه بگیرید.",
                "هالتر را به آرامی تا روی بخش وسطی سینه پایین بیاورید.",
                "با تمرکز بر انقباض سینه، هالتر را به سمت بالا پرس کنید تا دست‌ها صاف شوند."
            )
        ),
        GymExercise(
            id = "incline_db_press",
            nameEn = "Incline Dumbbell Press",
            nameFa = "پرس بالاسینه دمبل",
            categoryEn = "Chest",
            categoryFa = "سینه",
            descriptionEn = "Targets the upper clavicular portion of the pectoral muscle for complete chest development.",
            descriptionFa = "بخش بالایی عضلات سینه را برای فرم‌دهی و تقارن کامل سینه هدف قرار می‌دهد.",
            primaryMuscleEn = "Upper Pectorals",
            primaryMuscleFa = "بالاسینه",
            instructions = listOf(
                "روی نیمکت با شیب ۳۰ تا ۴۵ درجه بنشینید و دمبل‌ها را در سطح بالای سینه نگه دارید.",
                "دمبل‌ها را به طور همزمان به بالا پرس کنید تا آرنج‌ها قفل شوند.",
                "با کنترل کامل دمبل‌ها را به پایین و حالت شروع بازگردانید."
            )
        ),
        GymExercise(
            id = "cable_fly",
            nameEn = "Cable Crossover",
            nameFa = "کراس اور با کابل",
            categoryEn = "Chest",
            categoryFa = "سینه",
            descriptionEn = "Provides constant tension on the pectorals, emphasizing outer and inner chest separation.",
            descriptionFa = "تنش مداومی روی عضلات سینه ایجاد می‌کند و بر خط سینه و پهنای سینه تمرکز دارد.",
            primaryMuscleEn = "Inner & Outer Chest",
            primaryMuscleFa = "خط سینه",
            instructions = listOf(
                "کابل‌ها را در جایگاه بالا قرار دهید، دستگیره‌ها را بگیرید و یک گام به جلو بردارید.",
                "با آرنج‌های کمی خمیده، دست‌ها را به حالت قوسی در مقابل سینه به هم نزدیک کنید.",
                "با کنترل کابل‌ها را باز کنید تا کشش مناسبی در سینه احساس کنید."
            )
        ),
        // Back
        GymExercise(
            id = "pullup",
            nameEn = "Pull-up",
            nameFa = "بارفیکس",
            categoryEn = "Back",
            categoryFa = "پشت و زیربغل",
            descriptionEn = "One of the absolute best bodyweight movements to build width (wings) in your latissimus dorsi.",
            descriptionFa = "یکی از بهترین حرکات با وزن بدن برای ایجاد پهنا و فرم هفتی (V-taper) زیربغل.",
            primaryMuscleEn = "Latissimus Dorsi (Lats)",
            primaryMuscleFa = "عضلات پشتی بزرگ (زیربغل)",
            instructions = listOf(
                "میله بارفیکس را با دست‌های باز بگیرید و آویزان شوید.",
                "قفسه سینه را بالا نگه دارید و خود را تا جایی که چانه بالاتر از میله برود بالا بکشید.",
                "به آرامی و با کنترل به پایین بازگردید."
            )
        ),
        GymExercise(
            id = "lat_pulldown",
            nameEn = "Lat Pulldown",
            nameFa = "زیربغل سیم‌کش از جلو",
            categoryEn = "Back",
            categoryFa = "پشت و زیربغل",
            descriptionEn = "Excellent machine exercise that mimics the pull-up, allowing highly targeted lat simulation.",
            descriptionFa = "حرکت عالی با دستگاه که شبیه‌ساز بارفیکس است و اجازه اجرای هدفمند و متمرکز را می‌دهد.",
            primaryMuscleEn = "Lats & Upper Back",
            primaryMuscleFa = "پشتی بزرگ و بخش بالایی پشت",
            instructions = listOf(
                "روی صندلی بنشینید، ران‌ها را زیر پد محکم کنید و میله را با دست‌های باز بگیرید.",
                "میله را به سمت استخوان جناغ سینه پایین بکشید و شانه‌ها را به عقب فشار دهید.",
                "میله را با کنترل کامل به نقطه شروع هدایت کنید."
            )
        ),
        GymExercise(
            id = "barbell_row",
            nameEn = "Bent Over Barbell Row",
            nameFa = "زیربغل هالتر خم",
            categoryEn = "Back",
            categoryFa = "پشت و زیربغل",
            descriptionEn = "Great compound movement to build exceptional back thickness and mid-back density.",
            descriptionFa = "حرکت چندمفصلی عالی برای ایجاد ضخامت و چگالی خیره‌کننده در بخش میانی و بالایی پشت.",
            primaryMuscleEn = "Rhomboids & Traps",
            primaryMuscleFa = "بخش میانی پشت و ذوزنقه‌ای",
            instructions = listOf(
                "کمی زانوها را خم کنید، از باسن به جلو خم شوید در حالی که کمر کاملا صاف است.",
                "هالتر را به سمت زیر شکم خود بکشید و آرنج‌ها را نزدیک بدن نگه دارید.",
                "هالتر را به آرامی به پایین بازگردانید تا دست‌ها صاف شوند."
            )
        ),
        // Shoulders
        GymExercise(
            id = "overhead_press",
            nameEn = "Barbell Overhead Press",
            nameFa = "پرس سرشانه هالتر ایستاده",
            categoryEn = "Shoulders",
            categoryFa = "سرشانه",
            descriptionEn = "The ultimate test and builder of upper body pressing power and shoulder mass.",
            descriptionFa = "حرکت نهایی برای سنجش و ساخت قدرت بالاتنه و حجم عضلات دلتوئید (سرشانه).",
            primaryMuscleEn = "Anterior Deltoids",
            primaryMuscleFa = "دلتوئید قدامی (جلوی سرشانه)",
            instructions = listOf(
                "هالتر را در سطح شانه جلو نگه دارید، عضلات شکم و باسن را منقبض کنید.",
                "هالتر را مستقیماً بالای سر پرس کنید تا بازوها کاملا صاف شوند و با بدن هم‌راستا قرار گیرند.",
                "هالتر را با کنترل به آرامی تا بالای سینه خود پایین بیاورید."
            )
        ),
        GymExercise(
            id = "lateral_raise",
            nameEn = "Dumbbell Lateral Raise",
            nameFa = "نشر جانب دمبل",
            categoryEn = "Shoulders",
            categoryFa = "سرشانه",
            descriptionEn = "Isolation movement focusing on the lateral head, essential for creating that wide 3D shoulder look.",
            descriptionFa = "حرکت تک‌مفصلی با تمرکز روی بخش میانی دلتوئید که برای ساختن کتف عریض و پهن ضروری است.",
            primaryMuscleEn = "Lateral Deltoids",
            primaryMuscleFa = "دلتوئید جانبی (بخش میانی سرشانه)",
            instructions = listOf(
                "بایستید و در هر دست یک دمبل بگیرید، آرنج‌ها را به میزان بسیار کم خم کنید.",
                "دمبل‌ها را به طرفین بالا بیاورید تا دست‌ها با زمین موازی شوند (در امتداد شانه‌ها).",
                "به آرامی دمبل‌ها را به موقعیت شروع هدایت کنید."
            )
        ),
        // Legs
        GymExercise(
            id = "squat",
            nameEn = "Barbell Back Squat",
            nameFa = "اسکوات هالتر",
            categoryEn = "Legs",
            categoryFa = "پا",
            descriptionEn = "The undisputed king of leg development. Stimulates quad, hamstring, and glute growth.",
            descriptionFa = "پادشاه بی‌چون‌وچرای تمرینات پا. تحریک رشد عضلات چهارسر ران، همسترینگ و باسن.",
            primaryMuscleEn = "Quadriceps & Glutes",
            primaryMuscleFa = "چهارسر ران و باسن",
            instructions = listOf(
                "هالتر را روی بخش بالایی کول قرار دهید. پاها را به اندازه عرض شانه باز کنید.",
                "با به عقب فرستادن باسن و خم کردن زانوها بنشینید تا ران‌ها حداقل موازی با زمین شوند.",
                "با فشار به پاشنه پاها به حالت ایستاده شروع بازگردید در حالی که کمر را صاف نگه داشته‌اید."
            )
        ),
        GymExercise(
            id = "romanian_deadlift",
            nameEn = "Romanian Deadlift",
            nameFa = "ددلیفت رومانیایی",
            categoryEn = "Legs",
            categoryFa = "پا",
            descriptionEn = "Unparalleled for targets the posterior chain, specifically hamstrings and glutes.",
            descriptionFa = "حرکت بی‌رقیب برای تقویت زنجیره پشتی بدن به ویژه همسترینگ (پشت پا) و عضلات باسن.",
            primaryMuscleEn = "Hamstrings & Glutes",
            primaryMuscleFa = "همسترینگ و باسن",
            instructions = listOf(
                "هالتر را بگیرید و بایستید. از مفصل باسن شروع به خم شدن به جلو کنید در حالی که پاها تقریبا صاف و کمر قفل است.",
                "هالتر را مماس با پا بکشید و تا جایی پایین ببرید که کشش جدی در همسترینگ حس کنید.",
                "با باسن هدایت کرده و مجددا به حالت ایستاده برگردید د رحالی که باسن را منقبض می‌کنید."
            )
        ),
        // Arms
        GymExercise(
            id = "bicep_curl",
            nameEn = "Barbell Bicep Curl",
            nameFa = "جلو بازو هالتر ایستاده",
            categoryEn = "Arms",
            categoryFa = "بازو",
            descriptionEn = "The staple movement to isolate the bicep muscles and build incredible peak and thickness.",
            descriptionFa = "حرکتی بنیادی برای ایزوله کردن عضلات جلو بازو و ایجاد ارتفاع و ضخامت چشمگیر بازو.",
            primaryMuscleEn = "Biceps Brachii",
            primaryMuscleFa = "جلو بازو",
            instructions = listOf(
                "بایستید، هالتر را با چرخش مچ رو به بالا بگیرید و آرنج‌ها را چسبیده به بدن حفظ کنید.",
                "هالتر را با خم کردن آرنج‌ها به بالا بالا بکشید و عضلات جلو بازو را فشرده کنید.",
                "با کنترل کامل هالتر را پایین بیاورید تا بازوها مجددا کاملا صاف شوند."
            )
        ),
        GymExercise(
            id = "tricep_pushdown",
            nameEn = "Triceps Rope Pushdown",
            nameFa = "پشت بازو سیم‌کش طناب",
            categoryEn = "Arms",
            categoryFa = "بازو",
            descriptionEn = "Highly effective machine isolation that pumps the lateral and medial heads of the triceps.",
            descriptionFa = "حرکت تک‌مفصلی عالی با دستگاه سیم‌کش که سرهای جانبی و میانی عضله پشت بازو را پمپ می‌کند.",
            primaryMuscleEn = "Triceps Brachii",
            primaryMuscleFa = "پشت بازو",
            instructions = listOf(
                "روبه سیم‌کش بایستید و قرقره را بالا ببرید. انتهای طناب را بگیرید و آرنج‌ها را کنار بدن قفل کنید.",
                "طناب را به سمت پایین فشار دهید تا دست‌ها صاف شوند، در انتهای کار طناب را کمی به طرفین باز کنید.",
                "دست‌ها را به آرامی و با کنترل به بالا و حالت شروع برگردانید."
            )
        ),
        // Core
        GymExercise(
            id = "crunch",
            nameEn = "Abdominal Crunch",
            nameFa = "کرانچ شکم",
            categoryEn = "Core",
            categoryFa = "شکم و فیله",
            descriptionEn = "Classic target isolation exercise for developing the upper rectus abdominis (six-pack).",
            descriptionFa = "حرکت کلاسیک و ایزوله برای تقویت و شش تکه کردن شکم (عضله راست شکمی).",
            primaryMuscleEn = "Rectus Abdominis",
            primaryMuscleFa = "راست شکمی (شکم)",
            instructions = listOf(
                "به پشت روی زمین دراز بکشید و زانوها را خم کنید، دست‌ها را پشت گوش‌ها بگذارید.",
                "بدون کشیدن گردن، شانه‌ها را از زمین جدا کنید و شکم را تا چند سانتی‌متر منقبض کنید.",
                "به آرامی سرشانه را به زمین برگردانید."
            )
        ),
        GymExercise(
            id = "plank",
            nameEn = "Isometric Plank",
            nameFa = "پلانک شکم",
            categoryEn = "Core",
            categoryFa = "شکم و فیله",
            descriptionEn = "Excellent isometric hold that increases overall core stabilization and strength.",
            descriptionFa = "حرکت ایستایی (ایزومتریک) فوق‌العاده برای بالابردن ثبات کلی شکم، پهلو و کمر.",
            primaryMuscleEn = "Core Stability",
            primaryMuscleFa = "ثبات کل مرکز بدن",
            instructions = listOf(
                "ساعدها را روی زمین بگذارید و بدن را روی انگشتان پا صاف نگه دارید.",
                "شکم را منقبض و باسن را قفل کرده و از خم شدن کمر به پایین جلوگیری کنید.",
                "این حالت را به میزان زمان معین‌شده حفظ کنید و به طور مداوم نفس بکشید."
            )
        )
    )
}
