package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "workout_routines")
data class WorkoutRoutine(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "routine_exercises",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutRoutine::class,
            parentColumns = ["id"],
            childColumns = ["routineId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("routineId")]
)
data class RoutineExercise(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val routineId: Int,
    val exerciseName: String,
    val targetSets: Int = 3,
    val targetReps: String = "10",
    val targetWeight: Double = 20.0
)

@Entity(tableName = "workout_logs")
data class WorkoutLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val routineName: String,
    val timestamp: Long = System.currentTimeMillis(),
    val durationMinutes: Int = 0
)

@Entity(
    tableName = "exercise_set_logs",
    foreignKeys = [
        ForeignKey(
            entity = WorkoutLog::class,
            parentColumns = ["id"],
            childColumns = ["workoutLogId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("workoutLogId")]
)
data class ExerciseSetLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val workoutLogId: Int,
    val exerciseName: String,
    val setIndex: Int,
    val weight: Double,
    val reps: Int,
    val isCompleted: Boolean = true
)

@Dao
interface WorkoutDao {
    // Routines
    @Query("SELECT * FROM workout_routines ORDER BY createdAt DESC")
    fun getAllRoutines(): Flow<List<WorkoutRoutine>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutine(routine: WorkoutRoutine): Long

    @Query("DELETE FROM workout_routines WHERE id = :id")
    suspend fun deleteRoutineById(id: Int)

    // Exercises for Routine
    @Query("SELECT * FROM routine_exercises WHERE routineId = :routineId")
    fun getExercisesForRoutine(routineId: Int): Flow<List<RoutineExercise>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRoutineExercise(exercise: RoutineExercise)

    @Query("DELETE FROM routine_exercises WHERE routineId = :routineId")
    suspend fun deleteExercisesByRoutineId(routineId: Int)

    @Query("DELETE FROM routine_exercises WHERE id = :id")
    suspend fun deleteRoutineExerciseById(id: Int)

    // Workout logs
    @Query("SELECT * FROM workout_logs ORDER BY timestamp DESC")
    fun getAllWorkoutLogs(): Flow<List<WorkoutLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutLog(log: WorkoutLog): Long

    @Query("DELETE FROM workout_logs WHERE id = :id")
    suspend fun deleteWorkoutLogById(id: Int)

    // Exercise set logs
    @Query("SELECT * FROM exercise_set_logs WHERE workoutLogId = :workoutLogId ORDER BY id ASC")
    fun getSetLogsForWorkout(workoutLogId: Int): Flow<List<ExerciseSetLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetLog(setLog: ExerciseSetLog)
}

@Database(
    entities = [WorkoutRoutine::class, RoutineExercise::class, WorkoutLog::class, ExerciseSetLog::class],
    version = 1,
    exportSchema = false
)
abstract class GymDatabase : RoomDatabase() {
    abstract fun workoutDao(): WorkoutDao

    companion object {
        @Volatile
        private var INSTANCE: GymDatabase? = null

        fun getDatabase(context: Context): GymDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GymDatabase::class.java,
                    "gym_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class GymRepository(private val workoutDao: WorkoutDao) {
    val allRoutines: Flow<List<WorkoutRoutine>> = workoutDao.getAllRoutines()
    val allWorkoutLogs: Flow<List<WorkoutLog>> = workoutDao.getAllWorkoutLogs()

    fun getExercisesForRoutine(routineId: Int): Flow<List<RoutineExercise>> =
        workoutDao.getExercisesForRoutine(routineId)

    fun getSetLogsForWorkout(workoutLogId: Int): Flow<List<ExerciseSetLog>> =
        workoutDao.getSetLogsForWorkout(workoutLogId)

    suspend fun insertRoutine(routine: WorkoutRoutine): Long {
        return workoutDao.insertRoutine(routine)
    }

    suspend fun deleteRoutine(id: Int) {
        workoutDao.deleteRoutineById(id)
    }

    suspend fun insertRoutineExercise(exercise: RoutineExercise) {
        workoutDao.insertRoutineExercise(exercise)
    }

    suspend fun deleteRoutineExercise(id: Int) {
        workoutDao.deleteRoutineExerciseById(id)
    }

    suspend fun addWorkoutSession(routineName: String, durationMin: Int, sets: List<ExerciseSetLog>) {
        val logId = workoutDao.insertWorkoutLog(WorkoutLog(routineName = routineName, durationMinutes = durationMin))
        sets.forEach { set ->
            workoutDao.insertSetLog(set.copy(workoutLogId = logId.toInt()))
        }
    }

    suspend fun deleteWorkoutLog(id: Int) {
        workoutDao.deleteWorkoutLogById(id)
    }
}
