package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Carbon Dark Theme colors
val CarbonBg = Color(0xFF121212)
val CarbonSurface = Color(0xFF1E1E1E)
val CarbonCard = Color(0xFF2B2B2B)

val GoldPrimary = Color(0xFFFFB300)
val GoldVariant = Color(0xFFFF8F00)
val GoldSecondary = Color(0xFFFFC107)

val AccentRust = Color(0xFFE65100)
val GymOrange = Color(0xFFFF7043)
val GymGreen = Color(0xFF4CAF50)

val TextWhite = Color(0xFFF5F5F5)
val TextGray = Color(0xFFB0B0B0)
val TextDark = Color(0xFF121212)
