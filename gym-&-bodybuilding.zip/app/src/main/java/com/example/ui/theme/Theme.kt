package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CarbonDarkColorScheme = darkColorScheme(
    primary = GoldPrimary,
    secondary = GoldSecondary,
    tertiary = GymOrange,
    background = CarbonBg,
    surface = CarbonSurface,
    onPrimary = TextDark,
    onSecondary = TextDark,
    onTertiary = TextWhite,
    onBackground = TextWhite,
    onSurface = TextWhite,
    surfaceVariant = CarbonCard,
    onSurfaceVariant = TextWhite
)

private val CarbonLightColorScheme = lightColorScheme(
    primary = GoldVariant,
    secondary = GoldSecondary,
    tertiary = AccentRust,
    background = Color(0xFFF9F9F9),
    surface = Color.White,
    onPrimary = TextWhite,
    onSecondary = TextDark,
    onTertiary = TextWhite,
    onBackground = Color(0xFF1E1E1E),
    onSurface = Color(0xFF1E1E1E),
    surfaceVariant = Color(0xFFEEEEEE),
    onSurfaceVariant = Color(0xFF1E1E1E)
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme() || true, // Default to Dark Theme for that athletic elite feel!
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) CarbonDarkColorScheme else CarbonLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
